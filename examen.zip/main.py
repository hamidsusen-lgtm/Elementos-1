from machine import Pin, Timer
import time

# CONFIGURACIÓN DE PINES
# Botones
botonA = Pin(16, Pin.IN, Pin.PULL_UP)
botonB = Pin(17, Pin.IN, Pin.PULL_UP)

# LEDs
ledRojo = Pin(13, Pin.OUT)
ledAmarillo = Pin(14, Pin.OUT)
ledVerde = Pin(15, Pin.OUT)


# ESTADOS
BLOQUEADO = 0
ESPERANDO_B = 1
ACCESO = 2
SEGURIDAD = 3

estado = BLOQUEADO

intentos_fallidos = 0


#TEMPORIZADORES
timer = Timer()

TIPO_ESPERA = 1
TIPO_ACCESO = 2
TIPO_SEGURIDAD = 3

tipo_timer = None
evento_timer = False


evento_A = False
evento_B = False

ultimo_evento_A = 0
ultimo_evento_B = 0

TIEMPO_REBOTE = 300


def estado_bloqueado():
    ledRojo.on()
    ledAmarillo.off()
    ledVerde.off()


def estado_esperando():
    ledRojo.off()
    ledAmarillo.on()
    ledVerde.off()


def estado_acceso():
    ledRojo.off()
    ledAmarillo.off()
    ledVerde.on()


def estado_seguridad():
    ledRojo.on()
    ledAmarillo.off()
    ledVerde.off()


#TEMPORIZADOR
def timer_callback(timer):
    global evento_timer

    evento_timer = True


#ESPERA DE B
def iniciar_espera_B():
    global estado
    global tipo_timer

    estado = ESPERANDO_B
    estado_esperando()

    tipo_timer = TIPO_ESPERA

    timer.init(
        mode=Timer.ONE_SHOT,
        period=5000,
        callback=timer_callback
    )

    print("Esperando boton B durante 5 segundos...")


def conceder_acceso():
    global intentos_fallidos
    global estado
    global tipo_timer

    timer.deinit()

    intentos_fallidos = 0

    estado = ACCESO
    estado_acceso()

    tipo_timer = TIPO_ACCESO

    timer.init(
        mode=Timer.ONE_SHOT,
        period=3000,
        callback=timer_callback
    )

    print("ACCESO CONCEDIDO")



def registrar_fallo():
    global intentos_fallidos
    global estado

    intentos_fallidos += 1

    print("Intento fallido:", intentos_fallidos)

    if intentos_fallidos >= 3:
        iniciar_bloqueo_seguridad()

    else:
        estado = BLOQUEADO
        estado_bloqueado()



def iniciar_bloqueo_seguridad():
    global estado
    global tipo_timer

    estado = SEGURIDAD
    estado_seguridad()

    tipo_timer = TIPO_SEGURIDAD

    timer.init(
        mode=Timer.ONE_SHOT,
        period=10000,
        callback=timer_callback
    )

    print("BLOQUEO DE SEGURIDAD durante 10 segundos")

# INTERRUPCIÓN A

def interrupcion_A(pin):
    global ultimo_evento_A
    global evento_A

    ahora = time.ticks_ms()

    if time.ticks_diff(ahora, ultimo_evento_A) < TIEMPO_REBOTE:
        return

    ultimo_evento_A = ahora
    evento_A = True

# INTERRUPCIÓN B

def interrupcion_B(pin):
    global ultimo_evento_B
    global evento_B

    ahora = time.ticks_ms()

    if time.ticks_diff(ahora, ultimo_evento_B) < TIEMPO_REBOTE:
        return

    ultimo_evento_B = ahora
    evento_B = True


#INTERRUPCIONES
botonA.irq(
    trigger=Pin.IRQ_FALLING,
    handler=interrupcion_A
)

botonB.irq(
    trigger=Pin.IRQ_FALLING,
    handler=interrupcion_B
)

estado_bloqueado()


while True:

   
    #BOTÓN A
   

    if evento_A:
        evento_A = False

        if estado == BLOQUEADO:
            iniciar_espera_B()

        elif estado == ESPERANDO_B:
            print("A ignorado: ya se esta esperando B")

        elif estado == ACCESO:
            print("A ignorado durante acceso")

        elif estado == SEGURIDAD:
            print("A ignorado durante bloqueo de seguridad")

  
    #BOTÓN B
    if evento_B:
        evento_B = False

        if estado == BLOQUEADO:
            print("B presionado antes de A")
            registrar_fallo()

        elif estado == ESPERANDO_B:
            conceder_acceso()

        elif estado == ACCESO:
            print("B ignorado durante acceso")

        elif estado == SEGURIDAD:
            print("B ignorado durante bloqueo de seguridad")


    #EVENTO TEMPORIZADOR

    if evento_timer:
        evento_timer = False

        if tipo_timer == TIPO_ESPERA:

            print("TIMEOUT")
            registrar_fallo()

        elif tipo_timer == TIPO_ACCESO:

            print("Fin del acceso")

            estado = BLOQUEADO
            estado_bloqueado()

        elif tipo_timer == TIPO_SEGURIDAD:

            print("Fin del bloqueo de seguridad")

            intentos_fallidos = 0
            estado = BLOQUEADO
            estado_bloqueado()